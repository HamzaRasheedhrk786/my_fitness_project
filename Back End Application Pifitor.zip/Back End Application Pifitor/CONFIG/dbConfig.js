// module.exports ={
//     mongodbonline:"mongodb+srv://fitnessApp:fitnessApp@cluster0.8yfdg.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
// }
module.exports ={
    mongodbonline:"mongodb+srv://dbuser:dbuser@cluster0.v8xhw1c.mongodb.net/"
}