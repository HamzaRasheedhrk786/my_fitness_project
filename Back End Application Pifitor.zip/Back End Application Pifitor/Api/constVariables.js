const ALL = "ALL";
const RUNNING = "running";
const COMPLETED = "completed";
const REQUESTED="requested";
const ACCEPTED='accepted'
const REJECTED="rejected"
const RESTORED="restored"
const LOCAL="LOCAL"
const SOCIAL="SOCIAL"


module.exports = {
    ALL, 
    RUNNING,
    COMPLETED,
    REQUESTED,
    ACCEPTED,
    REJECTED,
    RESTORED,
    LOCAL,
    SOCIAL
}